<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('googlemaps');
		// $this->load->library('googlemaps');  => codingan ini kita ambil dari folder librari 
		$this->load->model('m_user');
	}

	public function index()
	{
		$this->user_login->cek_login();
		// coding di baris 17 merupakan kodingan untuk proteksi website. Jadi selai admin yg mmiliki username dan password tidak ada seorang pun yg bsa meng edit,input,dan simpan data.
		$data = array (

				'title' => 'Data User Admin',
				'map' => $this->googlemaps->create_map(),
				'user' => $this->m_user->lists(),
				'isi' => 'user/v_lists'
		);
		$this->load->view('template/v_wrapper', $data, FALSE);
	}

	public function login()
	{
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');

		if($this->form_validation->run()==TRUE) {	
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$this->user_login->login($username,$password);
		}

		$data = array (

				'title' => 'login',
				'map' => $this->googlemaps->create_map(),
				
				'isi' => 'v_login'
		);
		$this->load->view('template/v_wrapper', $data, FALSE);
	}

	public function logout()
	{
		$this->user_login->logout();
	}


// Fungsi Input Untuk Input data/Tambah data-------------------------------------------------------------------
	public function input()
	{
		$this->user_login->cek_login();
		// coding di baris 58 merupakan kodingan untuk proteksi website. Jadi selain admin yg mmiliki username dan password tidak ada seorang pun yg bsa meng edit,input,dan simpan data.

		$this->form_validation->set_rules('nama_user','Nama User','required');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		

		if ($this->form_validation->run()==FALSE) {
			$data = array (
				'title' => 'Input Data User Mamang Admin',
				'map' => $this->googlemaps->create_map(),
				'isi' => 'user/v_add'
		);
		$this->load->view('template/v_wrapper', $data, FALSE);
		}else{
			// $data = array() --> variabel data array akan di proses di folder models > M_rumkit dan di proses di dlam variabel ini : $this->db->insert('tbl_rumkit',$data);
			$data = array(

							'nama_user'=>$this->input->post('nama_user'),
							'username'=>$this->input->post('username'),
							'password'=>$this->input->post('password'),	
						 );
			// $this->m_rumkit->input($data); --> Untuk mengirim $data array ke dalam input agar di proses menjadi simpan data.
			$this->m_user->input($data);
			$this->session->set_flashdata('pesan', 'Data Berhasil Disimpan');
			redirect('user');
		}
		
	}
//End----------------------------------------------------------------------------------------- 

	public function edit($id_user)
	{
		$this->user_login->cek_login();
		// coding di baris 92 merupakan kodingan untuk proteksi website. Jadi selain admin yg mmiliki username dan password tidak ada seorang pun yg bsa meng edit,input,dan simpan data.
		$this->form_validation->set_rules('nama_user','Nama User','required');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');

		if ($this->form_validation->run()==FALSE) {
			$data = array (
				'title' => 'Input Data User Mamang Admin',
				'map' => $this->googlemaps->create_map(),
				'user' => $this->m_user->detail($id_user),
				'isi' => 'user/v_edit'
		);
		$this->load->view('template/v_wrapper', $data, FALSE);
		}else{
			// $data = array() --> variabel data array akan di proses di folder models > M_rumkit dan di proses di dlam variabel ini : $this->db->insert('tbl_rumkit',$data);
			$data = array(
							'id_user'=>$id_user,
						    'nama_user'=>$this->input->post('nama_user'),
							'username'=>$this->input->post('username'),
							'password'=>$this->input->post('password'),
						 );
			// $this->m_rumkit->input($data); --> Untuk mengirim $data array ke dalam input agar di proses menjadi simpan data.
			$this->m_user->edit($data);
			$this->session->set_flashdata('pesan', 'Data Berhasil Di Ubah !!!');
			redirect('user');
		}


		
	}

	public function delete($id_rumkit)
	{
		$this->user_login->cek_login();
		// coding di baris 126 merupakan kodingan untuk proteksi website. Jadi selain admin yg mmiliki username dan password tidak ada seorang pun yg bsa meng edit,input,dan simpan data.
		$data = array('id_rumkit' => $id_rumkit);
		$this->m_rumkit->delete($data);
		$this->session->set_flashdata('pesan', 'Data Berhasil Di hapus !!!');
		redirect('rumkit');
	}	

	

}
