<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('googlemaps');
		// $this->load->library('googlemaps');  => codingan ini kita ambil dari folder librari
		$this->load->model('m_rumkit'); 
	}

	public function index()
	{	
		$config	['center'] = '-0.9239946,100.3602393'; 
		// '-0.9239946,100.3602393'; => ini adalah titik kordinat pada maps.
		$config	['zoom'] = 15;
		// angka 15 itu adalah zoom ini sampe 15 kali.
		$this->googlemaps->initialize($config);

		// Pemetaan Keren, Ini Codingan Dari video 12
		$rumkit=$this->m_rumkit->lists();
		foreach ($rumkit as $key => $value) {
			$marker=array();
			$marker['position']="$value->latitude,$value->longitude";
			$marker['animation']="DROP";
			// Untuk animation pin, bisa menggunakan DROP/BOUNCE

			// berfungsi untuk membuat info ketika kta klik pin maps tersbut.
			$marker['infowindow_content'] ='<div class="media" style="width:250px;">';
			$marker['infowindow_content'] .='<div class="media-body">';
			$marker['infowindow_content'] .='<h5> Nama Rumkit :'.$value->nama_rumkit.'</h5>';
			$marker['infowindow_content'] .='<p> No Telpon : '.$value->no_telpon.'</p>';
			$marker['infowindow_content'] .='<p> Alamat :'.$value->alamat.'</p>';
			$marker['infowindow_content'] .='<p> Deskripsi :'.$value->deskripsi.'</p>';
			$marker['infowindow_content'] .='</div>';
			$marker['infowindow_content'] .='</div>';
		    // End---------------------------------------------------------------------------	
			$this->googlemaps->add_marker($marker);
			// $this->googlemaps->add_marker($marker); --> Berfungsi untuk menampilkan pin/penanda
			
		}
		

		$data = array (
// 
				'title' => 'Pemetaan Rumah Sakit Mamang Dwiki',
				'map' => $this->googlemaps->create_map(),
				'isi' => 'v_home'
		);
		$this->load->view('template/v_wrapper', $data, FALSE);
	}
}