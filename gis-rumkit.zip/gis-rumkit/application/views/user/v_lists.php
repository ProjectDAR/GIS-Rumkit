<div class="col-lg-12">
<div class="panel panel-primary">
<div class="panel-heading">
<?= $title ?>
</div>
       <!-- /.panel-heading -->
<div class="panel-body">
   <a href="<?= base_url('user/input') ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Input Data User </a>
   <div><br></div>

<!-- Untuk pesan ketika data tersimpan berhasil ini adalah codingan nya : -->
   <?php 
   if ($this->session->flashdata('pesan')) {
       echo '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
       echo $this->session->flashdata('pesan');
       echo '<a href="#" class="alert-link"></a></div>';
   }
   ?>
<!--End--------------------------------------------------------------------->

<div class="table-responsive">
    <table  class="table table-striped table-bordered table-hover" id="dataTables-example">	
        <thead>	
             <tr>
        	 <th>NO</th>
        	  <th>Nama User</th>
        	   <th>Username</th>
        	    <th>Password</th>
        	    <th>Action</th>
             </tr>
         </thead>

         <tbody>
            <?php $no=1; foreach ($user as $key => $value) {?>
        <tr>	
            <td>  <?= $no++; ?> </td>
            <td> <?= $value->nama_user ?> </td>
            <td> <?= $value->username ?> </td> 
            <td> <?= $value->password ?> </td>
            
            <td>
              <a href="<?= base_url('user/edit/'.$value->id_user); ?>" class="btn btn-success btn-sm">Edit</a>
              <a href="" class="btn btn-danger btn-sm" onclick="return confirm ('Apakah data ingin dihapus?')">Delete</a>
           </td>
        </tr>
         <?php } ?>
         </tbody>

   	</table>
    </div>
    </div>
    </div>
    </div>