 <div class="col-lg-7">
  <div class="panel panel-primary">
     <div class="panel-heading"><i class="fa fa-plus"></i>
           Lokasi rumah sakit
     </div>
         <div class="panel-body">
              <?= $map['html']; ?>
         </div>
         </div>
         </div>
      

<div class="col-lg-5">
 <div class="panel panel-green">
  <div class="panel-heading">
           Edit data rumah sakit
  </div>
      <div class="panel-body">
              <!-- Form Input Data -->
          <?php echo form_open('rumkit/edit/'.$rumkit->id_rumkit);?>
              <!-- rumkit/input, input ini kita ambil dari function input dalam folder controller>rumkit -->
          <div class="form-group">
            <label>Nama Rumah sakit</label>
            <input class="form-control" value=" <?=$rumkit->nama_rumkit ?>" name="nama_rumkit" placeholder="Nama Rumah Sakit" required>
          </div>

           <div class="form-group">
            <label>No Telpon</label>
            <input class="form-control" value="<?=$rumkit->no_telpon?>" name="no_telpon" placeholder="No Telpon" required>
          </div>

           <div class="form-group">
            <label>Alamat</label>
            <input class="form-control" value="<?=$rumkit->alamat?>" name="alamat" placeholder="Alamat" required>
          </div>

           <div class="form-group">
            <label>Latitude</label>
            <input class="form-control" value="<?=$rumkit->latitude?>" name="latitude" placeholder="Latitude" readonly>
          </div>

           <div class="form-group">
            <label>Longitude</label>
            <input class="form-control" value="<?=$rumkit->longitude?>" name="longitude" placeholder="longitude" readonly>
          </div>

          <div class="form-group">
            <label>Deskripsi</label>
           <textarea class="form-control" name="deskripsi" cols="50" required><?=$rumkit->deskripsi?></textarea>
          </div>

           <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Simpan</button>
            <button class="btn btn-success btn-sm" type="reset">Reset</button>
          </div>

          <?php echo form_close() ?>
              <!-- Form   
      </div>
      </div>